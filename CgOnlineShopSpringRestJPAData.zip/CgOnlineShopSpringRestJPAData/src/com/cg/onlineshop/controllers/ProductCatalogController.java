package com.cg.onlineshop.controllers;
import java.awt.PageAttributes.MediaType;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;
import com.cg.onlineshop.services.OnlineShopServices;
@RestController
public class ProductCatalogController {
	@Autowired
	private OnlineShopServices onlineShopServices; 
	
	@RequestMapping("/hello")
	public ResponseEntity<String> sayHello(){

		ResponseEntity<String> response = new ResponseEntity<String>("Hello to All", HttpStatus.OK);
		return response;
	}
	
	@RequestMapping(value="/acceptProductDetails",method=RequestMethod.POST,consumes=org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptProductDetails(@ModelAttribute Product product){
		onlineShopServices.acceptProductDetails(product);
		return new ResponseEntity<String>("Product Details Successfully added",HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/getAllProductDetails",method=RequestMethod.POST,consumes=org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> getAllProductDetails(){
		List<Product>   res =  onlineShopServices.getAllProductDetails();
		//List<JSONObject>details = new ArrayList<JSONObject>(); 
		return new ResponseEntity<String>("abc"+res,HttpStatus.OK);
		}
	
	@RequestMapping(value="/getProductDetails",method=RequestMethod.POST)
	public ResponseEntity<String> getProductDetails(){
		Product product = null;
		try {
			 product=onlineShopServices.getProductDetails(111);
		} catch (ProductDetailsNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseEntity<String>(product.toString(),HttpStatus.OK);
		
	}
	
	

	
	
}
