package com.cg.banking.services;
import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
public interface BankingServices {
	int  openAccount(String accountType,float initBalance,int pinNumber,String status);
	float depositAmount(int accountNo,float amount);
	float withdrawAmount(int accountNo,float amount,int pinNumber);
	boolean fundTransfer(int accountNoTo,int accountNoFrom,float transferAmount,int pinNumber) ;
	Account getAccountDetails(int accountNo);
	ArrayList<Account> getAllAccountDetails();
	List<Transaction> getAccountAllTransaction(int accountNo);
}