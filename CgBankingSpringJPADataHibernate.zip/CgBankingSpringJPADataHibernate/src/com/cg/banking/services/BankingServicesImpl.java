package com.cg.banking.services;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
@Component(value="bankingServices")
public class BankingServicesImpl implements BankingServices {
	@Autowired
	private AccountDAO accountDAO;
	@Autowired
	private TransactionDAO transactionDAO;
	@Override
	public int openAccount(String accountType, float initBalance,int pinNumber,String status){
		Account account=new Account(pinNumber, accountType, status, initBalance);	
		accountDAO.save(account);	
		return account.getAccountNo();
	}
	@Override
	public float depositAmount(int accountNo, float amount){
		Account account;
		account = getAccountDetails(accountNo);
		account.setAccountBalance(account.getAccountBalance()+amount);
		Transaction transaction=new Transaction(amount, "Deposit",new Account(accountNo));
		transactionDAO.save(transaction);
		accountDAO.save(account);
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(int accountNo, float amount, int pinNumber)  {
		Account account;
		account = getAccountDetails(accountNo);
		if(account.getAccountBalance()-amount>1000&&account.getPinNumber()==pinNumber){
			account.setAccountBalance(account.getAccountBalance()-amount);
			Transaction transaction=new Transaction(amount, "Withdraw",new Account(accountNo));
			transactionDAO.save(transaction);
			accountDAO.save(account);
		}
		else
			System.out.println("Insufficient Balance!!Withdrawal Failed");
		return account.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(int accountNoTo, int accountNoFrom, float transferAmount, int pinNumber){
		Account account1;
		account1 = getAccountDetails(accountNoTo);
		Account account2=getAccountDetails(accountNoFrom);
		if(account2.getAccountBalance()-transferAmount>1000&&account2.getPinNumber()==pinNumber){
			account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
			account2.setAccountBalance(account2.getAccountBalance()-transferAmount);
			Transaction transaction1=new Transaction(transferAmount, "Transfer",new Account(accountNoTo));
			Transaction transaction2=new Transaction(transferAmount, "Transfer",new Account(accountNoFrom));
			transactionDAO.save(transaction1);
			transactionDAO.save(transaction2);
			accountDAO.save(account1);
			accountDAO.save(account2);
		}
		else
			System.out.println("Insufficient Balance!!Withdrawal Failed");
		return false;
	}
	@Override
	public Account getAccountDetails(int accountNo)  {
		Account account=accountDAO.findById(accountNo).get();
		return account;		
	}
	@Override
	public ArrayList<Account> getAllAccountDetails() {	
		return (ArrayList<Account>) accountDAO.findAll();
	}
	@Override
	public List<Transaction> getAccountAllTransaction(int accountNo){	
		Account account=accountDAO.findById(accountNo).get();
		return account.getTransactions();
	}
}