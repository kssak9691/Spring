package com.cg.banking.client;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.banking.services.BankingServices;
public class MainClass {
	public static void main(String[] args)  {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbean.xml");
		BankingServices services=(BankingServices) applicationContext.getBean("bankingServices");
		int accountNo1=services.openAccount("Savings", 20000,1023,"Active");
		int accountNo2=services.openAccount("Savings",25000,3201,"Active");
		System.out.println(accountNo1);	
		services.depositAmount(accountNo1, 4000);
		System.out.println(services.getAccountDetails(accountNo1).getAccountBalance());
		services.withdrawAmount(accountNo1,1500,1023);
		System.out.println(services.getAccountDetails(accountNo1).getAccountBalance());
		services.fundTransfer(accountNo1,accountNo2,3000,3201);
		System.out.println(services.getAccountDetails(accountNo1).getAccountBalance());
		System.out.println(services.getAccountDetails(accountNo2).getAccountBalance());
		System.out.println(services.getAllAccountDetails());
		System.out.println(services.getAccountAllTransaction(accountNo1));
	}
}