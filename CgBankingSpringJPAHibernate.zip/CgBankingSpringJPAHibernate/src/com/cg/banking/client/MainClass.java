package com.cg.banking.client;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
public class MainClass {
	public static void main(String[] args)  {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices services=(BankingServices) applicationContext.getBean("bankingServices");
		long accountNo=services.openAccount("Savings", 15000,1234,"Active");
		System.out.println(accountNo);
//		BankingServices services=new BankingServicesImpl();
//
//		long accountNo=services.openAccount("Savings", 15000,1234,"Active");
//		System.out.println("Savings account opened with account number= "+accountNo);
//		long accountNo1= services.openAccount("Current", 5000, 2345, "Active");
//		System.out.println("Current account opened with account number= "+accountNo1);
//		services.openAccount("Salary", 10000,3465,"Active");
//		float accBal=services.depositAmount(accountNo, 2000);
//		System.out.println(accBal);
//		services.withdrawAmount(111114, 1000, 1234);
//		services.fundTransfer(accountNo,accountNo1 , 1000, 2345);
//		System.out.println(services.getAccountAllTransaction(accountNo).toString());		
	}
}