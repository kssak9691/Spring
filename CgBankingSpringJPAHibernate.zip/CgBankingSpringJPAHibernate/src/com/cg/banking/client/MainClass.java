package com.cg.banking.client;
import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

import antlr.collections.List;
public class MainClass {
	public static void main(String[] args)  {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices services=(BankingServices) applicationContext.getBean("bankingServices");
		int accountNo=services.openAccount("Savings", 10000,1234,"offline");
		//System.out.println(accountNo);
		//services.depositAmount(1001, 500);
		//services.getAccountAllTransaction(1001);
		
		/*arr=services.getAccountAllTransaction(1);
		 for(int i=0;i<arr.size();i++) {

	            System.out.println(arr.get(i).toString());
	         
	        }
*/		//System.out.println(services.getAccountDetails(1001).toString());
//		BankingServices services=new BankingServicesImpl();
//
//		long accountNo=services.openAccount("Savings", 15000,1234,"Active");
//		System.out.println("Savings account opened with account number= "+accountNo);
//		long accountNo1= services.openAccount("Current", 5000, 2345, "Active");
//		System.out.println("Current account opened with account number= "+accountNo1);
//		services.openAccount("Salary", 10000,3465,"Active");
//		float accBal=services.depositAmount(accountNo, 2000);
//		System.out.println(accBal);
//		services.withdrawAmount(111114, 1000, 1234);
//		services.fundTransfer(accountNo,accountNo1 , 1000, 2345);
//		System.out.println(services.getAccountAllTransaction(accountNo).toString());		
	}
}