package com.cg.billing.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.billing.services.BillingServices;

public class MainClass {
	public static void main(String[] args){
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		BillingServices billingServices=(BillingServices) applicationContext.getBean("billingServices");
		
	}
}