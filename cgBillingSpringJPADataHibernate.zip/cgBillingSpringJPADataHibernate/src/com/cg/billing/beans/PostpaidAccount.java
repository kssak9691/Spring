package com.cg.billing.beans;
import java.util.Map;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity
public class PostpaidAccount {
	@Id
	private long mobileNo;
	@OneToOne
	private Plan plan;
	@ManyToOne
	private Customer customer;
	@OneToMany(mappedBy="postpaidAccount")
	private  Map<Integer, Bill> bills;
	public PostpaidAccount() {
		super();
	}
	public PostpaidAccount(Plan plan, Customer customer) {
		super();
		this.plan = plan;
		this.customer = customer;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Plan getPlan() {
		return plan;
	}
	public void setPlan(Plan plan) {
		this.plan = plan;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Map<Integer, Bill> getBills() {
		return bills;
	}
	public void setBills(Map<Integer, Bill> bills) {
		this.bills = bills;
	}
}