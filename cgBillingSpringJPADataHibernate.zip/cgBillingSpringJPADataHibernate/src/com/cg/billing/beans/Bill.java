package com.cg.billing.beans;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.TableGenerator;
@Entity
@TableGenerator(name="seq_billID", initialValue=100, allocationSize=20)
public class Bill {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="seq_billID")
	private int billID;
	private int noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits;
	private String billMonth;
	private float totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, servicesTax, vat;
	@ManyToOne
	private PostpaidAccount postpaidAccount;
}