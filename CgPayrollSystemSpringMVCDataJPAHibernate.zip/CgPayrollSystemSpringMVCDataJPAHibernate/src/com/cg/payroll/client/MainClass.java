package com.cg.payroll.client;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.*;
import com.cg.payroll.services.*;
public class MainClass {
	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbean.xml");
		PayrollServicesImpl payrollServices=(PayrollServicesImpl) applicationContext.getBean("payrollServices");
		int associateId=payrollServices.acceptAssociateDetails(15000,"Abhi","Kaush","DEO","Sr.Analyst","CBSJO1520L","ak@gmail.com",125053,"HDFC","HDFC153125",5000,300,200);
		System.out.println(associateId);
		System.out.println(payrollServices.calculateNetSalary(associateId));
		
		
		/*
		PayrollServices payrollServices = new PayrollServicesImpl();
		int associateId=payrollServices.acceptAssociateDetails(10000,"David","Billa","CSE","Sr.Con","CWD0707D","david@gmail.com" ,202366,"HDFC","HDFC357355",20000,1000,2000);
		payrollServices.calculateNetSalary(associateId);
		Associate associate=payrollServices.getAssociateDetails(associateId);
		System.out.println(associate.toString());
		*/
	}
}