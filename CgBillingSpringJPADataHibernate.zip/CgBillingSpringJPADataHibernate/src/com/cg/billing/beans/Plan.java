package com.cg.billing.beans;
import java.util.Map;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.TableGenerator;
@Entity
@TableGenerator(name="seq_planID", initialValue=2000, allocationSize=20)
public class Plan {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="seq_planID")
	private int planID;
	private int monthlyRental, freeLocalCalls, freeStdCalls, freeLocalSMS, freeStdSMS, freeInternetDataUsageUnits;
	private float localCallRate, stdCallRate, localSMSRate, stdSMSRate, internetDataUsageRate;
	private String planCircle, planName;
	@OneToMany(mappedBy="plan")
	private Map<Long, PostpaidAccount> postpaidAccounts;
	public Plan() {
		super();
	}
	public Plan(int planID) {
		super();
		this.planID = planID;
	}
}