package com.cg.billing.services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.billing.beans.*;
import com.cg.billing.daoservices.*;
import com.cg.billing.exceptions.*;
@Component(value="billingServices")
public class BillingServicesImpl implements BillingServices {
	public static long MOBILE_NO=6000000000l;
	private BillingDAO billingDAO;
	@Autowired
	private CustomerDAO customerDAO;
	@Autowired
	private PlanDAO planDAO;
	@Autowired
	private PostpaidDAO postpaidDAO;
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailID, String dateOfBirth,
			int pinCode, String state, String city)
					throws BillingServicesDownException {
		Customer customer=new Customer(firstName, lastName, emailID, dateOfBirth, new Address(pinCode, city, state));
		customerDAO.save(customer);
		return customer.getCustomerID();
	}
	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).get();
		return customer;
	}
	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		return customerDAO.findAll();
	}
	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		customerDAO.deleteById(customerID);
		return false;
	}
	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).get();
		return (List<PostpaidAccount>) customer.getPostpaidAccounts();
	}
	@Override
	public List<Plan> getAllPlanDetails() throws BillingServicesDownException {
		return planDAO.findAll();
	}
	@Override
	public long openPostpaidAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		PostpaidAccount postpaidAccount=new PostpaidAccount( new Plan(planID), new Customer(customerID));
		postpaidAccount.setMobileNo(++MOBILE_NO);
		return postpaidAccount.getMobileNo();
	}










	
	@Override
	public int generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
					throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
					BillingServicesDownException, PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		return postpaidDAO.findById((int) mobileNo).get();
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
	PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}



}