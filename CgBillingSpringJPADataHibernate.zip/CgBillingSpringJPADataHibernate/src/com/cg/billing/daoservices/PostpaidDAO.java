package com.cg.billing.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.cg.billing.beans.PostpaidAccount;
public interface PostpaidDAO extends JpaRepository<PostpaidAccount, Integer> {
	@Query("SELECT a FROM PostpaidAccount a WHERE a.mobileNo=?1")
	PostpaidAccount getPostPaidAccountDetails(long mobileNo);
}