package com.cg.mobilebilling.services;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.mobilebilling.beans.*;
import com.cg.mobilebilling.daoservices.*;
import com.cg.mobilebilling.exceptions.*;
@Component("billingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	BillingDAOServices billingDAO;
	@Autowired
	CustomerDAOServices customerDAO;
	@Autowired
	PlanDAOServices planDAO;
	@Autowired
	PostpaidDAOServices postpaidDAO;
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		return planDAO.findAll();
	}
	@Override
	public Customer acceptCustomerDetails(Customer customer) throws BillingServicesDownException {
		customerDAO.save(customer);
		return customer;
	}
	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).get();
		if(customer==null) throw new CustomerDetailsNotFoundException("Sorry Customer details not found!!!");
		Plan plan=planDAO.findById(planID).get();
		if(plan==null) throw new PlanDetailsNotFoundException("Sorry requested plan is unavailable!!!");
		PostpaidAccount postpaid=new PostpaidAccount(plan, customer);
		postpaidDAO.save(postpaid);
		return postpaid.getMobileNo();
	}
	@Override
	public Bill generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
					throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
					BillingServicesDownException, PlanDetailsNotFoundException {
		PostpaidAccount postpaid=postpaidDAO.findById(mobileNo).get();
		if(postpaid==null) throw new PostpaidAccountNotFoundException("Requested PostPaid Account does not exist!!!");
		Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, postpaid, billMonth);
		if(noOfLocalSMS>postpaid.getPlan().getFreeLocalSMS())
			bill.setLocalSMSAmount((noOfLocalSMS-postpaid.getPlan().getFreeLocalSMS())*postpaid.getPlan().getLocalSMSRate());
		else
			bill.setLocalSMSAmount(0);
		if(noOfStdSMS>postpaid.getPlan().getFreeStdSMS())
		bill.setStdSMSAmount((noOfStdSMS-postpaid.getPlan().getFreeStdSMS())*postpaid.getPlan().getStdSMSRate());
		else
			bill.setStdSMSAmount(0);
		if(noOfLocalCalls>postpaid.getPlan().getFreeLocalCalls())
		bill.setLocalCallAmount((noOfLocalCalls-postpaid.getPlan().getFreeLocalCalls())*postpaid.getPlan().getLocalCallRate());
		else
			bill.setLocalCallAmount(0);
		if(noOfStdCalls>postpaid.getPlan().getFreeStdCalls())
		bill.setStdCallAmount((noOfStdCalls-postpaid.getPlan().getFreeStdCalls())*postpaid.getPlan().getStdCallRate());
		else
			bill.setStdCallAmount(0);
		if(internetDataUsageUnits>postpaid.getPlan().getFreeInternetDataUsageUnits())
		bill.setInternetDataUsageAmount((internetDataUsageUnits-postpaid.getPlan().getFreeInternetDataUsageUnits())*postpaid.getPlan().getInternetDataUsageRate());
		else
			bill.setInternetDataUsageAmount(0);
		float intialamount=bill.getLocalSMSAmount()+bill.getLocalCallAmount()+bill.getStdSMSAmount()+bill.getStdCallAmount()+bill.getInternetDataUsageAmount()+postpaid.getPlan().getMonthlyRental();
		bill.setCgst((intialamount*5)/100);
		bill.setSgst((intialamount*5)/100);
		bill.setTotalBillAmount(intialamount+bill.getCgst()+bill.getSgst());
		billingDAO.save(bill);
		return bill;
	}
	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {

		return customerDAO.findById(customerID).get();
	}
	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		return customerDAO.findAll();
	}
	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).get();
		if(customer==null) throw new CustomerDetailsNotFoundException("Sorry Customer details not found!!!");
		PostpaidAccount postpaid=postpaidDAO.getPostPaidAccountDetails(customer, mobileNo);
		return postpaid;
	}
	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).get();
		if(customer==null) throw new CustomerDetailsNotFoundException("Sorry Customer details not found!!!");
		List<PostpaidAccount> postpaid=new ArrayList<>();
		postpaid=postpaidDAO.getCustomerAllPostpaidAccountsDetails(customer);
		return postpaid;
	}
	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).get();
		if(customer==null) throw new CustomerDetailsNotFoundException("Sorry Customer details not found!!!");
		PostpaidAccount postpaid=postpaidDAO.findById(mobileNo).get();
		if(postpaid==null) throw new PostpaidAccountNotFoundException("Sorry Postpaid Account details not found!!!");
		Bill bill=billingDAO.getMobileBillDetails(postpaid ,billMonth);
		if(bill==null) throw new InvalidBillMonthException("Entered Bill month dosen't exists");
		else
		return bill;
	}
	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).get();
		if(customer==null) throw new CustomerDetailsNotFoundException("Sorry Customer details not found!!!");
		List<Bill> bill=new ArrayList<>();
		bill=postpaidDAO.getCustomerPostPaidAccountAllBillDetails(customer, mobileNo);
		return bill;
	}
	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
	PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).get();
		if(customer==null) throw new CustomerDetailsNotFoundException("Sorry Customer details not found!!!");
		Plan plan=planDAO.findById(planID).get();
		if(plan==null) throw new PlanDetailsNotFoundException("Sorry requested plan is unavailable!!!");
		PostpaidAccount postpaid=new PostpaidAccount(mobileNo, plan, customer);
		postpaidDAO.save(postpaid);
		return true;
	}
	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).get();
		if(customer==null) throw new CustomerDetailsNotFoundException("Sorry Customer details not found!!!");
		return postpaidDAO.closeCustomerPostPaidAccount(customer, mobileNo);
	}
	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		customerDAO.deleteById(customerID);
		return false;
	}
	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).get();
		if(customer==null) throw new CustomerDetailsNotFoundException("Sorry Customer details not found!!!");
		Plan plan=postpaidDAO.getCustomerPostPaidAccountPlanDetails(customer, mobileNo);
		return plan;
	}
}