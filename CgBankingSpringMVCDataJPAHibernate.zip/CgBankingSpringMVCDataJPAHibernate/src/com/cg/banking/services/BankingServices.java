package com.cg.banking.services;
import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.*;
public interface BankingServices {
	float depositAmount(int accountNo,float amount);
	float withdrawAmount(int accountNo,float amount,int pinNumber);
	boolean fundTransfer(int accountNoTo,int accountNoFrom,float transferAmount,int pinNumber) ;
	Account getAccountDetails(int accountNo);
	ArrayList<Account> getAllAccountDetails();
	List<Transaction> getAccountAllTransaction(int accountNo);
	Account openAccount(Account account);
}