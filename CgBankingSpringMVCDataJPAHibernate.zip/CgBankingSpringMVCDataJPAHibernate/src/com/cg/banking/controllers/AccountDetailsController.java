package com.cg.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;

@Controller
public class AccountDetailsController {
	@Autowired
	private BankingServices bankingServices;
	@RequestMapping("/displayAccountDetails")
	public ModelAndView DepositAmount(@RequestParam("accountNo")int accountNo) {
		Account account=bankingServices.getAccountDetails(accountNo);
		return new ModelAndView("displayAccountDetailsPage","account",account);
	}
}
