package com.cg.payroll.beans;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
public class Associate {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int  associateId;
	private int yearlyInvestmentUnder80c;
	@NotEmpty
	private String  firstName;
	@NotEmpty
	private String lastName;
	@NotEmpty
	private String department;
	@NotEmpty
	private String designation;
	@NotEmpty
	private String pancard;
	@NotEmpty
	private String emailId;
	@Embedded
	private BankDetails bankdetails;
	@Embedded
	private Salary salary;
	public Associate() {
		super();
	}
	public Associate(int associateId, int yearlyInvestmentUnder80c,
			String firstName, String lastName, String department,
			String designation, String pancard, String emailId,
			BankDetails bankdetails, Salary salary) {
		super();
		this.associateId = associateId;
		this.yearlyInvestmentUnder80c = yearlyInvestmentUnder80c;
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.designation = designation;
		this.pancard = pancard;
		this.emailId = emailId;
		this.bankdetails = bankdetails;
		this.salary = salary;
	}
	public Associate(int yearlyInvestmentUnder80C, String firstName, String lastName, String department,
			String designation, String pancard, String emailId, BankDetails bankDetails, Salary salary) {
		super();
		this.yearlyInvestmentUnder80c = yearlyInvestmentUnder80C;
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.designation = designation;
		this.pancard = pancard;
		this.emailId = emailId;
		this.bankdetails = bankDetails;
		this.salary = salary;
	}	
	public Associate(int associateId, int yearlyInvestmentUnder80c,
			String firstName, String lastName, String department,
			String designation, String pancard, String emailId) {
		super();
		this.associateId = associateId;
		this.yearlyInvestmentUnder80c = yearlyInvestmentUnder80c;
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.designation = designation;
		this.pancard = pancard;
		this.emailId = emailId;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public int getYearlyInvestmentUnder80c() {
		return yearlyInvestmentUnder80c;
	}
	public void setYearlyInvestmentUnder80c(int yearlyInvestmentUnder80c) {
		this.yearlyInvestmentUnder80c = yearlyInvestmentUnder80c;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public BankDetails getBankdetails() {
		return bankdetails;
	}
	public void setBankdetails(BankDetails bankdetails) {
		this.bankdetails = bankdetails;
	}
	public Salary getSalary() {
		return salary;
	}
	public void setSalary(Salary salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Associate [associateID=" + associateId
				+ ", yearlyInvestmentUnder80c=" + yearlyInvestmentUnder80c
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", department=" + department + ", designation=" + designation
				+ ", pancard=" + pancard + ", emailId=" + emailId
				+ ", bankdetails=" + getBankdetails() + ", salary=" + getSalary() + "]";
	}
}