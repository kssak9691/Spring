package com.cg.project.client;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.project.beans.*;
import com.cg.project.services.*;
public class MainClass {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("projectbean.xml");
		PayrollServices payrollServices =(PayrollServices) context.getBean("PayrollServices");
		int associateId=payrollServices.acceptAssociateDetails(10000,"David","Billa","CSE","Sr.dev","CWD0707","david@gmail.com" ,202366,"HDFC","HDFC357355",20000,1000,2000);
		payrollServices.calculateNetSalary(associateId);
		Associate associate=payrollServices.getAssociateDetails(associateId);
		System.out.println(associate.toString());
	}
}