package com.cart.service;

public interface EmailService {

	public void mail(String mailId,String userName, String message, String subject);
}
