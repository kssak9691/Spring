package com.cg.mobilebilling.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;



public class MainClass {
	public static void main(String[] args){
		ApplicationContext context=new ClassPathXmlApplicationContext("projectbeans.xml");
		BillingServices billingServices=(BillingServices) context.getBean("billingServices");
		try {
			//int customerId=billingServices.acceptCustomerDetails("Renuka", "Indukuri", "indukuri.renuka@gmail.com", "19/10/1996", "Pune", "Maharashtra", 411057);
			//System.out.println(billingServices.getPlanAllDetails());
			//long mobileNo=billingServices.openPostpaidMobileAccount(111, 1);
			//System.out.println(mobileNo);
			//System.out.println(billingServices.getCustomerAllPostpaidAccountsDetails(111));
			billingServices.generateMonthlyMobileBill(111, 791119999, "January", 600, 800, 1200, 1500, 1500);
			System.out.println(billingServices.getCustomerPostPaidAccountAllBillDetails(111, 791119999));
		} catch (BillingServicesDownException e) {
			e.printStackTrace();
		} catch (CustomerDetailsNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PostpaidAccountNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BillDetailsNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidBillMonthException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PlanDetailsNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}