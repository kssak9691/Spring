package com.cg.banking.client;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServices;
public class MainClass {
	public static void main(String[] args)  {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices services=(BankingServices) applicationContext.getBean("bankingServices");
		int accountNo1=services.openAccount("Savings", 15000,1234,"Active");
		int accountNo2=services.openAccount("Savings", 25000,5678,"Active");
		System.out.println(accountNo1);
		services.depositAmount(accountNo1,5000);
		
		System.out.println(services.getAccountDetails(accountNo1).getAccountBalance());
		/*
		services.withdrawAmount(accountNo1,2000,1234);
		System.out.println(services.getAccountDetails(accountNo1).getAccountBalance());
		services.fundTransfer(accountNo1, accountNo2, 2000, 5678);
		System.out.println(services.getAccountDetails(accountNo1).getAccountBalance());
		System.out.println(services.getAccountDetails(accountNo2).getAccountBalance());
		
		System.out.println(services.getAllAccountDetails());
		
		System.out.println(services.getAccountAllTransaction(accountNo1));
		*/

	}
}