package com.cg.banking.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.banking.beans.Account;
public interface AccountDAO extends JpaRepository<Account, Integer>{
	
	/*
	Account saveAccountDetails(Account account) ;
	Account getAccountDetails(long accountNo) ;
	int updateTransaction(Transaction transaction);
	boolean updateAccount(Account account) ;
	ArrayList<Transaction> getAccountAllTransactionDetails(long accountNumber) ;
	ArrayList<Account> getAllAccountDetails() ;
	*/

	
	
}